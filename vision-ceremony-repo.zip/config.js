// Supabase 연결 정보 — 프로젝트 설정 → API 에서 복사해 넣으세요.
// anon public key 는 웹페이지용 공개 키라 저장소에 올려도 됩니다. (service_role key 는 절대 넣지 마세요)
window.SUPA_URL = 'https://YOUR-PROJECT.supabase.co';
window.SUPA_KEY = 'YOUR-ANON-PUBLIC-KEY';
